import React, { } from "react";


const Box = (props) => {
    return (
        <div>

        </div>
      );
    }
export default Box;
    